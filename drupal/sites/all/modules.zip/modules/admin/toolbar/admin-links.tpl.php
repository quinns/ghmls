<?php if ($links): ?>

<div class='admin-inline'>
  <div class='admin-border admin-border-top'></div>
  <div class='admin-border admin-border-right'></div>
  <div class='admin-border admin-border-bottom'></div>
  <div class='admin-border admin-border-left'></div>
  <div class='admin-links clear-block'><?php print $links ?></div>
</div>

<?php endif; ?>
Drupal.behaviors.drupal_notifier = function () {
    $("#edit-upload").click( function() {
      $("#edit-drupal-notifier-icon-upload").attr('checked','true');
    });
};

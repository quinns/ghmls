// $Id: README.txt,v 1.1.2.1 2009/04/20 22:51:08 aaron Exp $

Views Slideshow: Thumbnail Hover

The original alternate slideshow mode for Views Slideshow.

 *  The Views Slideshow: ThumbnailHover works with node views only.
 *  It adds two parts to the view: the first part is a series of items
 *  displayed as a list, while the second part is either full or teaser.
 *  The slide show will synchronize the two, so that the 'active' item
 *  will correspond to the single full/teaser item. The slide show can
 *  be set to move automatically and/or on mouse hover.

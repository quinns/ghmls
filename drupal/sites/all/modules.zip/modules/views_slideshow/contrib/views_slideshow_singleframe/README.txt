// $Id: README.txt,v 1.1.2.1 2009/04/16 02:04:52 aaron Exp $

Views Slideshow: SingleFrame

The original default slideshow mode for Views Slideshow.

/* $Id: README.txt,v 1.4 2008/09/30 20:10:22 aaron Exp $ */

/****************/
 Views Slideshow
/****************/

Author: Aaron Winborn
Development Began 2007-07-18
Port to Drupal 6 on 2008-09-30

Requires: Views 2

This module will create a View type of 'Slideshow' that will display nodes in a jquery slideshow. Depending on the mode,
slideshows may either be displayed in a single element, or in a single element with thumbnails/teasers in another.
Settings are available for fade, timing, mode, and more.

Questions can be directed to winborn at advomatic dot com

<?php
// $Id: faq-new-page.tpl.php,v 1.1.2.1 2008/06/12 11:16:30 snpower Exp $

/**
 * @file
 * Template file for the FAQ page if set to show the answer in a new page.
 */

/**
 * Available variables:
 *
 * $list_style
 *   The style of the list, either ol or ul (ordered list or unordered list).
 * $list_items
 *   An array of nodes to be displayed in the list.
 * $list
 *   Pre-formatted list.
 */
?>
<?php
print $list;

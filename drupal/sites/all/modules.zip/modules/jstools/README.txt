jstools

README

Description
------------

As of Drupal 6, Javascript Tools is a small helper module containing methods
useful to other Drupal modules using Javascript. Modules formerly distributed
with Javascript Tools are being moved selectively to their own projects for 
separate download.
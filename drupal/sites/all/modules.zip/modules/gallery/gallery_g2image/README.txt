// $Id: README.txt,v 1.1.2.1 2008/06/10 12:56:35 profix898 Exp $

Installation
------------

If you install G2Image (http://g2image.steffensenfamily.com) as either a
standalone or TinyMCE plugin you will have an excellent image chooser for
Drupal/Gallery2. The configuration is automatic when you hit the 'Save
configuration' button on the G2Image settings page
(admin/settings/gallery/g2image).

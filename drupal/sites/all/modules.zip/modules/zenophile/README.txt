$Id: README.txt,v 1.2 2009/04/30 23:51:15 garrettalbright Exp $

Zenify
by Garrett Albright
My Drupal user page:
http://drupal.org/user/191212

This module's project page:
http://drupal.org/project/zenophile

This module aids in the initial setup of Zen subthemes. If you don't know what
Zen subthemes are or why you'd want to create one, you probably shouldn't use
this module.


FIFTEEN SECOND HOW-TO:

1. Install this module like any other module.

2. If necessary, go to Administration > Users > Permissions and grant groups the
'create theme with zenophile' permission.

3. Go to Aministration > Site building > Themes and click the "Create Zen
subtheme" tab. Everything on this page should be fairly self-explanatory.

4. When you're done creating themes, you may want to deactivate the module. It
won't stress the server too much if it remains active, but it will take up a
bit of RAM and processor cyclage while providing no added functionality to the
site.